<!-- Main content -->
<section class="content"> 
    <div class="row">
        <div class="box-tools pull-right" style="margin: 14px 20px 14px 0;">
            <button type="button" class="btn btn-primary btn-modal" data-href="{{action('\Modules\MPCS\Http\Controllers\F15FormController@get15FormSetting')}}" data-container=".form_15_settings_modal">
                <i class="fa fa-plus"></i> @lang( 'mpcs::lang.add_15_form_settings' )</button>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            @component('components.widget', ['class' => 'box-primary'])
                <div class="col-md-12">
                    <div class="box-body" style="margin-top: 20px;">
                        <div class="row">
                            <div class="col-md-12">
                                <div id="msg"></div>
                                <div class="table-responsive">
                                    <table id="form_15_settings_table" class="table table-striped table-bordered" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Description</th>
                                                <th>Value</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Data will be populated here -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endcomponent
        </div>
    </div>

    <!-- Modal for adding form settings -->
    <div class="modal fade form_15_settings_modal" id="form_15_settings_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>
    <!-- Modal for updating form settings -->
    <div class="modal fade update_form_15_settings_modal" id="update_form_15_settings_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>

</section>


<!-- JavaScript -->
<script type="text/javascript">
    $(document).ready(function() {
    var form_15_settings_table = $('#form_15_settings_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "{{ action('\Modules\MPCS\Http\Controllers\F15FormController@mpcs15FormSettings') }}",
            type: 'GET',
            data: function(d) {
                d.json_data = JSON.stringify({
                    "data": [
                        { "id": 1, "prefix": "store_purchase_up_to_previous_day", "description": "Store Purchases" },
                        { "id": 2, "prefix": "", "description": "Direct Purchase" },
                        { "id": 3, "prefix": "", "description": "Sub Total" },
                        { "id": 4, "prefix": "", "description": "Price Increment" },
                        { "id": 5, "prefix": "", "description": "Changes" },
                        { "id": 6, "prefix": "total_up_to_previous_day", "description": "Total" },
                        { "id": 7, "prefix": "opening_stock_up_to_previous_day", "description": "Opening Stock" },
                        { "id": 8, "prefix": "grand_total_up_to_previous_day", "description": "Grand Total" },
                        { "id": 9, "prefix": "cash_sales_up_to_previous_day", "description": "Cash Sale" },
                        { "id": 10, "prefix": "card_sales_up_to_previous_day", "description": "Card Sale" },
                        { "id": 11, "prefix": "credit_sales_up_to_previous_day", "description": "Credit Sale" },
                        { "id": 12, "prefix": "", "description": "Total" },
                        { "id": 13, "prefix": "", "description": "Changes (18)" },
                        { "id": 14, "prefix": "", "description": "Price Reduction" },
                        { "id": 15, "prefix": "", "description": "Damaged" },
                        { "id": 16, "prefix": "", "description": "Others" },
                        { "id": 17, "prefix": "", "description": "Total Return" },
                        { "id": 18, "prefix": "total_31_up_to_previous_day", "description": "Total" },
                        { "id": 19, "prefix": "balance_stock_in_sale_price_up_to_previous_day", "description": "Balance Stock in Sale Price" }
                    ]
                });
            },
            error: function(xhr, error, thrown) {
                console.log('Ajax error:', xhr.status, error, thrown);
                alert('Error loading data: ' + thrown);
            }
        },
        columns: [
            {
                data: null,
                render: function(data, type, row) {
                    return `
                        <table class="table table-bordered">
                            <tr>
                                <td>${row.description}</td>
                                <td>${data[row.prefix]}</td>
                                <td>
                                    <button class="btn btn-primary btn-sm edit-btn" data-href="{{ action('\Modules\MPCS\Http\Controllers\F15FormController@get15FormSetting') }}?id=${data.id}" data-container=".form_15_settings_modal">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <button class="btn btn-danger btn-sm delete-btn" onclick="deleteFormSetting(this)" data-href="{{ action('\Modules\MPCS\Http\Controllers\F15FormController@delete15FormSetting') }}?id=${data.id}">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </table>
                    `;
                }
            }
        ],
        columnDefs: [
            { 
                targets: '_all', 
                className: 'text-center' 
            }
        ]
    });

    // Submit Update Form 15 Settings
    $(document).on('submit', 'form#update_15_form_settings', function(e) {
        e.preventDefault();
        $(this).find('button[type="submit"]').attr('disabled', true);
        var data = $(this).serialize();

        $.ajax({
            method: $(this).attr('method'),
            url: $(this).attr('action'),
            dataType: 'json',
            data: data,
            success: function(result) {
                if (result.success == true) {
                    toastr.success(result.msg);
                    form_15_settings_table.ajax.reload(); // Refresh the table
                    $('#update_form_15_settings_modal').modal('hide'); 
                } else {
                    toastr.error(result.msg);
                }
                $('button[type="submit"]').attr('disabled', false);
            },
            error: function(xhr, status, error) {
                toastr.error(error);
                $('button[type="submit"]').attr('disabled', false);
            }
        });
    });
});

// Function to delete Form Setting
function deleteFormSetting(button) {
    var url = button.getAttribute('data-href');
    
    if (confirm("Are you sure you want to delete this setting?")) {
        fetch(url, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                toastr.success(data.msg); // Success message
                button.closest('tr').remove(); // Remove the row from table after success
            } else {
                toastr.error(data.msg); // Error message
            }
        })
        .catch(error => {
            console.error('Error:', error);
            toastr.error("Something went wrong.");
        });
    }
}
</script>