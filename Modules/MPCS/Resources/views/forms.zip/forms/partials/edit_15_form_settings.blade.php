<style>
    .form-container {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        width: 48%; /* Membagi menjadi dua kolom */
    }

    .form-group label {
        font-weight: bold;
    }

    .form-group input {
        width: 100%;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .form-group .full-width {
        width: 100%; /* Untuk input yang harus penuh di satu kolom */
    }
</style>
 <div class="modal-dialog" role="document" style="width: 50%;">
    <div class="modal-content">
        {!! Form::open(['url' => action('\Modules\MPCS\Http\Controllers\F15FormController@mpcs15Update', [$settings->id]), 
            'method' => 'post', 
            'id' => 'update_15_form_settings' ]) !!}

        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <h4 class="modal-title">@lang( 'mpcs::lang.edit_15_form_settings' )</h4>
        </div>

        <div class="modal-body">
            <div class="col-md-12">
                <div class="form-container">
                    <div class="form-group full-width">
    <label for="form_date">@lang('Date & Time')</label>
    <input type="text" name="dated_at" id="form_date" class="form-control" value="{{ $settings->dated_at ?? date('Y-m-d') }}" readonly> 
</div>

<!-- F 15 Form Starting Number -->
<div class="form-group">
    <label for="f15_start_number">@lang('F 15 Form Starting Number')</label>
    <input type="text" name="f15_form_start_number" id="f15_start_number" class="form-control" value="{{ $settings->f15_form_start_number ?? '' }}" readonly >
</div>

<!-- Ref Previous Form Number -->
<div class="form-group">
    <label for="ref_previous_form">@lang('Ref Previous Form Number')</label>
    <input type="text" name="ref_previous_form" id="ref_previous_form" class="form-control" value="{{ $settings->ref_previous_form ?? '' }}" required>
</div>

<!-- Store Purchases Amount Up to Previous Day -->
<div class="form-group">
    <label for="store_purchase">@lang('Store Purchases Amount Up to Previous Day')</label>
    <input type="number" step="0.01" name="store_purchase_up_to_previous_day" id="store_purchase" class="form-control" value="{{ $settings->store_purchase_up_to_previous_day ?? '' }}" required>
</div>

<!-- Total (No 17) Up to Previous Day -->
<div class="form-group">
    <label for="total_up_to_previous_day">@lang('Total (No 17) Up to Previous Day')</label>
    <input type="number" step="0.01" name="total_up_to_previous_day" id="total_up_to_previous_day" class="form-control" value="{{ $settings->total_up_to_previous_day ?? '' }}" required>
</div>

<!-- Opening Stock Up to Previous Day -->
<div class="form-group">
    <label for="opening_stock">@lang('Opening Stock Up to Previous Day')</label>
    <input type="number" step="0.01" name="opening_stock_up_to_previous_day" id="opening_stock" class="form-control" value="{{ $settings->opening_stock_up_to_previous_day ?? '' }}" required>
</div>

<!-- Grand Total Up to Previous Day -->
<div class="form-group">
    <label for="grand_total">@lang('Grand Total Up to Previous Day')</label>
    <input type="number" step="0.01" name="grand_total_up_to_previous_day" id="grand_total" class="form-control" value="{{ $settings->grand_total_up_to_previous_day ?? '' }}" required>
</div>

<!-- Cash Sales Up to Previous Day -->
<div class="form-group">
    <label for="cash_sales">@lang('Cash Sales Up to Previous Day')</label>
    <input type="number" step="0.01" name="cash_sales_up_to_previous_day" id="cash_sales" class="form-control" value="{{ $settings->cash_sales_up_to_previous_day ?? '' }}" required>
</div>

<!-- Card Sales Up to Previous Day -->
<div class="form-group">
    <label for="card_sales">@lang('Card Sales Up to Previous Day')</label>
    <input type="number" step="0.01" name="card_sales_up_to_previous_day" id="card_sales" class="form-control" value="{{ $settings->card_sales_up_to_previous_day ?? '' }}" required>
</div>

<!-- Credit Sales Up to Previous Day -->
<div class="form-group">
    <label for="credit_sales">@lang('Credit Sales Up to Previous Day')</label>
    <input type="number" step="0.01" name="credit_sales_up_to_previous_day" id="credit_sales" class="form-control" value="{{ $settings->credit_sales_up_to_previous_day ?? '' }}" required>
</div>

<!-- Total (No 31) Up to Previous Day -->
<div class="form-group">
    <label for="total_up_to_previous_day_31">@lang('Total (No 31) Up to Previous Day')</label>
    <input type="number" step="0.01" name="total_31_up_to_previous_day" id="total_up_to_previous_day_31" class="form-control" value="{{ $settings->total_31_up_to_previous_day ?? '' }}" required>
</div>

<!-- Balance Stock in Sale Price Up to Previous Day -->
<div class="form-group">
    <label for="balance_stock">@lang('Balance Stock in Sale Price Up to Previous Day')</label>
    <input type="number" step="0.01" name="balance_stock_in_sale_price_up_to_previous_day" id="balance_stock" class="form-control" value="{{ $settings->balance_stock_in_sale_price_up_to_previous_day ?? '' }}" required>
</div>

<!-- Grand Total Again -->
<div class="form-group">
    <label for="grand_total_again">@lang('Grand Total Again')</label>
    <input type="number" step="0.01" name="grand_total_again" id="grand_total_again" class="form-control" value="{{ $settings->grand_total_again ?? '' }}" required>
</div>
                </div> 
            </div> 
        </div>

        <div class="modal-footer">
            <button type="submit" class="btn btn-primary">@lang( 'messages.update' )</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">@lang( 'messages.close' )</button>
        </div>
        {!! Form::close() !!}
    </div>
</div>

<script>
    $(document).ready(function() {
        $('form#update_15_form_settings').validate();
    });
</script>