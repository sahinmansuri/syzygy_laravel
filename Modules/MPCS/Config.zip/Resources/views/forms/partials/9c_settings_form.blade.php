<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-3 text-red">
            <b>@lang('mpcs::lang.date_and_time'): <span class="9c_from_date">{{ $date }}</span> </b>
        </div>
        <div class="col-md-3 text-red">
            <b>@lang('mpcs::lang.ref_previous_form_number'): <span class="9c_from_date">{{ $form_number }}</span> </b>
        </div>
        <div class="col-md-3">
            <div class="text-center">
                <h5 style="font-weight: bold;">@lang('mpcs::lang.user_added'): {{ $name }} <br>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="box-tools pull-right" style="margin: 14px 20px 14px 0;">
            <button type="button" class="btn btn-primary btn-modal" onclick="openModal()">
                <i class="fa fa-plus"></i> @lang('mpcs::lang.add_form_9_c_settings')</button>
        </div>
    </div>

    <div id="myModal" class="modal" style="width: 30%; margin: auto; margin-top: 20px;">
        <div class="modal-content" style="padding: 10px;">
            <span class="close" onclick="closeModal()">&times;</span>
            <form action="{{ route('mpcs.store_form_9c_cash') }}" method="post">
                @csrf
                <div class="mb-4" style="margin-bottom: 10px;">
                    <label for="exampleInputEmail1" class="form-label">Date & Time</label>
                    <input type="text" class="form-control" @readonly(true) id="datetime" value="{{ Carbon::now()->format('Y/m/d') }}" data-date-format="yyyy/mm/dd" name="date_added">
                </div>
                <div class="mb-3" style="margin-bottom: 10px;">
                    <label for="exampleInputPassword1" class="form-label">Form Starting Number</label>
                    <input type="text" class="form-control" id="exampleInputPassword1" name="form_starting_number">
                </div>
                <div class="mb-3" style="margin-bottom: 10px;">
                    <label for="exampleInputPassword1" class="form-label">Previous Sheet Amount</label>
                    <input type="text" class="form-control" id="exampleInputPassword1" name="previous_sheet_amount">
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
                <span class="close btn btn-default" onclick="closeModal()">Close</span>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById("myModal").style.display = "block";
        }
        u

        function closeModal() {
            document.getElementById("myModal").style.display = "none";
        }

        // Close modal when clicking outside the content
        window.onclick = function(event) {
            let modal = document.getElementById("myModal");
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>

    {{-- <div class="row">
        <div class="col-md-12">
            @component('components.widget', ['class' => 'box-primary'])
                <div class="col-md-12">
                    <div class="box-body" style="margin-top: 20px;">
                        <div class="row">
                            <div class="col-md-12">

                                <div id="msg"></div>
                                <table id="form_9a_settings_table" class="table table-striped table-bordered"
                                    cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th>@lang('mpcs::lang.action')</th>
                                            <th>@lang('mpcs::lang.form_starting_number')</th>
                                            <th>@lang('mpcs::lang.total_sale_up_to_previous_day')</th>
                                            <th>@lang('mpcs::lang.previous_day_cash_sale')</th>
                                            <th>@lang('mpcs::lang.previous_day_card_sale')</th>
                                            <th>@lang('mpcs::lang.previous_day_credit_sale')</th>
                                            <th>@lang('mpcs::lang.previous_day_cash')</th>
                                            <th>@lang('mpcs::lang.previous_day_cheques_cards')</th>
                                            <th>@lang('mpcs::lang.previous_day_total')</th>
                                            <th>@lang('mpcs::lang.previous_day_balance_in_hand')</th>
                                            <th>@lang('mpcs::lang.previous_day_grand_total')</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            @endcomponent
        </div>
    </div> --}}

    <div class="container">
        <h3 class="text-center">Data Table</h3>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Action</th>
                    <th>Date & Time</th>
                    <th>Form Starting Number</th>
                    <th>Previous Note</th>
                    <th>User Added</th>
                </tr>
            </thead>
            @foreach ($get_data as $items)
            <tbody>
                <tr>
                    <td>
                        <button class="btn btn-primary btn-xs" onclick="editRow()">Edit</button>
                    </td>
                    <td>{{ \Carbon\Carbon::parse($items->date_added)->diffForHumans() }}</td>
                    <td>{{ $items->from_starting_number }}</td>
                    <td>{{ $items->previous_sheet_amount }}</td>
                    <td>{{ $items->name }}</td>
                </tr>
            </tbody>
            @endforeach
        </table>
    </div>
    
    <script>
        function editRow() {
            alert("Only Super Admin is permitted to edit.");
        }
    </script>

</section>
<!-- /.content -->

<script>
    $('#datepicker').datepicker('setDate', new Date());
</script>

