<!-- Main content -->
<style>
    body {
        background-color: white;
    }
    .form-container {
        padding: 20px;
        border: 1px solid #ddd;
        background: white;
    }
    .no-print {
        display: none;
    }
</style>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            @component('components.filters', ['title' => __('report.filters')])

            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('form_9a_location_id', __('purchase.business_location') . ':') !!}
                    {!! Form::select('form_9a_location_id', $business_locations, null, ['class' => 'form-control select2',
                    'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); !!}
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('form_9a_date', __('date') . ':') !!}
                    {!! Form::date('datepicker', date('Y-m-d'), [
                        'class' => 'form-control',
                        'placeholder' => __( 'mpcs::lang.date_and_time' ),
                        'id' => 'form_9a_date'
                    ]) !!}
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    {!! Form::label('type', __('mpcs::lang.from_no') . ':') !!}
                    {!! Form::text('form_9a_no', $form_9a_no ?? '', ['class' => 'form-control', 'readonly']) !!}
                </div>
            </div>

            @endcomponent
        </div>
    </div>

    {{-- <div class="row">
        <div class="col-md-12">
            @component('components.widget', ['class' => 'box-primary'])
            @slot('tool')
            <div class="box-tools">
                <!-- Standard Print button -->
                <button class="btn btn-primary print_report pull-right" id="print_div">
                    <i class="fa fa-print"></i> @lang('messages.print')</button>
            </div>
            @endslot
            <div class="col-md-12">

                <div class="row" style="margin-top: 20px;" id="print_content">
                    <style>
                    </style>
                    <div class="col-md-12">
                        <h4>@lang('mpcs::lang.daily_sales_report')</h4>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped" id="form_9b_table">
                                        <thead class="align-middle">
                                            <tr class="align-middle text-center">
                                                <th class="align-middle text-center" rowspan="2">@lang('mpcs::lang.description')</th>
                                                <th class="align-middle text-center" colspan="2">Total Sale</th>
                                                <th class="align-middle text-center" colspan="2">Card Sale</th>
                                                <th class="align-middle text-center" colspan="2">Cash Sale</th>
                                                <th class="align-middle text-center" colspan="2">Empty Barrels</th>
                                                <th class="align-middle text-center" colspan="2">Others</th>
                                                <th class="align-middle text-center" colspan="2">Total</th>
                                                <th class="align-middle text-center" colspan="2">With Taxes</th>
                                                <th class="align-middle text-center" colspan="2">Without Taxes</th>
                                                <th class="align-middle text-center" rowspan="2">Office Use</th>
                                            </tr>
                                            <tr class="align-middle" style="text-align: center;">
                                                <td>Rupees</td>
                                                <td>Cents</td>
                                                <td>Rupees</td>
                                                <td>Cents</td>
                                                <td>Rupees</td>
                                                <td>Cents</td>
                                                <td>Rupees</td>
                                                <td>Cents</td>
                                                <td>Rupees</td>
                                                <td>Cents</td>
                                                <td>Rupees</td>
                                                <td>Cents</td>
                                                <td>Rupees</td>
                                                <td>Cents</td>
                                                <td>Rupees</td>
                                                <td>Cents</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th>Cash</th>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td id="card_sales"></td> <!-- Total Card Sales -->
                                                <td></td>
                                                <td id="cash_sales"></td> <!-- Total Cash Sales -->
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td id="total_cash_sale"></td> <!-- Total = Card Sales + Cash Sales -->
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td rowspan="7">
                                                    <p>Rceived On ...........................</p>
                                                    <p>Checked ................................</p>
                                                    <p>Approved .............................</p>
                                                    <p style="text-align: center;">After Checking</p>
                                                    <p style="display: flex; justify-content: center; gap: 10px;">
                                                        <span style="text-decoration-line: underline;"> Short Money </span>
                                                        <span style="text-decoration-line: underline;"> Excess Money </span>
                                                    </p>
                                                    <p>Today ...................................</p>
                                                    <p>Previous Day ........................</p>
                                                    <p>As of Today ...........................</p>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Deposit / Credit Sales</th>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td id="total_credit_sale"></td> <!-- Total Credit Sales -->
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <th> &nbsp; </th>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td> <!--  -->
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <th>MPCS Branches</th>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <th>Today Sale</th>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td id="total_sale"></td> <!-- 6 + 7 -->
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <th>Total Sale up to Previous Day</th>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td id="total_sale_pre_day"></td> <!-- Total Sale up to Previous Day -->
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <th>Total Sale as of Today</th>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td id="total_sale_today"></td> <!-- 8 + 9 -->
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
            @endcomponent
        </div>
    </div> --}}

    <div class="container form-container bg-white">
        <h3 class="text-center">Form 9 C</h3>
        
        <!-- Location Name (Auto Load) -->
        <div class="form-group">
            <label>Location Name:</label>
            <input type="text" class="form-control" id="location_name" readonly>
        </div>
        
        <!-- Form No (Auto Increment) -->
        <div class="form-group">
            <label>Form No:</label>
            <input type="text" class="form-control" id="form_no" readonly>
        </div>
        
        <!-- Date Picker -->
        <div class="form-group">
            <label>Date:</label>
            <input type="text" class="form-control" id="date_picker">
        </div>
        
        <!-- Table -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Bill No</th>
                    <th>Product Name</th>
                    <th>Qty</th>
                    <th>Page</th>
                    <th>Total Amount</th>
                    <th>Goods</th>
                    <th>Loading</th>
                    <th>Empty</th>
                    <th>Transport</th>
                    <th>Other</th>
                </tr>
            </thead>
            <tbody>
                <!-- Dynamic Rows Will Be Added Here -->
            </tbody>
        </table>
        
        <!-- Totals -->
        <div class="form-group">
            <label>This Document Total:</label>
            <input type="text" class="form-control" id="doc_total" readonly>
        </div>
        <div class="form-group">
            <label>Previous Note Total:</label>
            <input type="text" class="form-control" id="prev_note_total" readonly>
        </div>
        <div class="form-group">
            <label>Total:</label>
            <input type="text" class="form-control" id="final_total" readonly>
        </div>
        
        <!-- Buttons -->
        <button class="btn btn-success no-print">Save</button>
        <button class="btn btn-primary no-print" onclick="window.print();">Save & Print</button>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            // Auto Load Location Name (Dummy Value)
            $('#location_name').val('Auto Loaded Location');
            
            // Auto Increment Form No (Dummy Value)
            $('#form_no').val('1001');
            
            // Date Picker (Using jQuery UI)
            $('#date_picker').datepicker({ dateFormat: 'yy-mm-dd' });
            
            // Prevent Print Buttons from showing on print
            $(".no-print").each(function(){
                $(this).attr('onClick', 'return false;');
            });
        });
    </script>

</section>
<!-- /.content -->