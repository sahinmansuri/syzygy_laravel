<?php

namespace Modules\MPCS\Http\Controllers;

use App\Brands;
use App\Business;
use App\BusinessLocation;
use App\Category;
use App\Product;
use App\Store;
use App\Unit;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\MPCS\Entities\MpcsFormSetting;
use Yajra\DataTables\Facades\DataTables;
use App\Utils\ModuleUtil;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Utils\Util;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB; 
use Modules\MPCS\Entities\Mpcs15FormSettings;
use Modules\MPCS\Entities\FormF15TransactionData; 
use Modules\MPCS\Entities\FormF15Header; 
use App\Contact;
use App\Transaction;
class F15FormController extends Controller
{
    /**
     * All Utils instance.
     *
     */
    protected $transactionUtil;
    protected $productUtil;
    protected $moduleUtil;
    protected $util;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(TransactionUtil $transactionUtil, ProductUtil $productUtil, ModuleUtil $moduleUtil, Util $util)
    {
        $this->transactionUtil = $transactionUtil;
        $this->productUtil = $productUtil;
        $this->moduleUtil = $moduleUtil;
        $this->util = $util;
    }


    /**
     * Display a listing of the resource.
     * @return Response
     */
   
    
    
    public function index(Request $request)
{
      
    $business_id = request()->session()->get('business.id');
    $settings = MpcsFormSetting::where('business_id', $business_id)->first(); 

    $suppliers = Contact::suppliersDropdown($business_id, false);
    $business_locations = BusinessLocation::forDropdown($business_id); 
    $setting = MpcsFormSetting::where('business_id', $business_id)->first(); 
          
             
              //$form_f15 = FormF15Detail::where('transaction_id', $lastRecord['id'])->first();
                return view('mpcs::forms.F15')->with(compact(
                    'business_locations',
                    'setting',
                    'suppliers'
                ));
            }


 
    public function getFormF15Data(Request $request)
{ 
    $startDate = $request->input('startDate');
    $endDate = $request->input('endDate'); 
    $startDate = $startDate ? $startDate : date('Y-m-d');
    $endDate = $endDate ? $endDate : date('Y-m-d');

    $query = FormF15TransactionData::with(['details' => function($query) use ($startDate, $endDate) { 
        $query->whereBetween('dated_at', [$startDate, $endDate]);
    }])
    ->whereHas('details', function ($query) {
        $query->whereColumn('description_id', 'form_f15_transaction_data.id');
    })
    ->orderBy('id');

    $data = $query->get(); 
    $grandTotal = [
        'previous_date_rupees' => 0,
        'previous_date_cts' => 0,
        'today_rupees' => 0,
        'today_cts' => 0,
        'as_of_today_rupees' => 0,
        'as_of_today_cts' => 0,
    ];
 
    foreach ($data as $transaction) {
        foreach ($transaction->details as $detail) {
            $detailDate = $detail->dated_at; 
            if ($detailDate < $startDate) {
                $grandTotal['previous_date_rupees'] += $detail->rupees;
                $grandTotal['previous_date_cts'] += $detail->cts;
            }
            if ($detailDate === $startDate) {
                $grandTotal['today_rupees'] += $detail->rupees;
                $grandTotal['today_cts'] += $detail->cts;
            }
            $grandTotal['as_of_today_rupees'] += $detail->rupees;
            $grandTotal['as_of_today_cts'] += $detail->cts;
        }
    }

    return response()->json([
        'data' => $data,
        'grandTotal' => $grandTotal, // Include grand totals
    ]);
}




}
